"""Student Expense Tracker package."""
__version__ = "1.0.0"
